<?php include 'header.php' ?>
</head>

<body>
	<?php include 'nav.php' ?>

	<div class="container">
		<div class="jumbotron">
			
<h2>Hi.</h2>
<p>I'm Test McDerpson,</p>
<p style="font-size:80%;">
Test Test Test
</p>

<div class="progress progress-striped active">
  <div class="progress-bar"  role="progressbar" aria-valuenow="67" aria-valuemin="0" aria-valuemax="100" style="width: 45%">
    <span class="sr-only">67% Complete</span>
  </div>
</div>

<center>
<!-- Button trigger modal -->
<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
  Launch demo modal
</button>
</center>
<br>
<img style="display:block;margin-left:auto;margin-right:auto;" src="http://placehold.it/600x200" class="img-rounded img-responsive">
<div style="text-align:center;"><i><h5>Image!</h5></i></div>



<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Modal title</h4>
      </div>
      <div class="modal-body">
        <p>One fine body&hellip;</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


		</div>
	</div>

<?php include 'footer.php' ?>

