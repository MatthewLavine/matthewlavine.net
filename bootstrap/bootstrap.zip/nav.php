<div class="navbar navbar-default navbar-fixed-top" role="navigation">
<div class="container">

<div class="navbar-header">
    	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav1">
      		<span class="sr-only">Toggle navigation</span>
      		<span class="icon-bar"></span>
     	 	<span class="icon-bar"></span>
      		<span class="icon-bar"></span>
    	</button>
	<a class="navbar-brand" href="#">Test McDerpson</a>
</div>

<div class="collapse navbar-collapse" id="nav1">
	<ul class="nav navbar-nav">
      		<li><a href="#">Foo</a></li>
      		<li><a href="#">Bar</a></li>
      		<li class="dropdown">
        		<a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown<b class="caret"></b></a>
			<ul class="dropdown-menu">
          			<li><a href="#">Foo</a></li>
         			<li class="divider"></li>
          			<li><a href="#">Bar</a></li>
        		</ul>
      		</li>
      		<li><a href="#">Herp</a></li>
    	</ul>
    	<ul class="nav navbar-nav navbar-right">
        	<li><a href="#">LinkedIn</a></li>
         	<li><a href="#">GitHub</a></li>
	 </ul>
</div><!-- /.navbar-collapse -->

</div>
</div>


<br><br><br><br>

