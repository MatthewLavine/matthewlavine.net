        <div id="footer">
                <div class="container">
                        <p class="text-muted credit">Designed using <a href="http://getbootstrap.com/">Bootstrap</a>. &copy;2014</p>
                </div>
        </div>

        <script src="https://code.jquery.com/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
</body>
</html>
